#!/bin/bash

# Ensure the script is run as root
if [[ $EUID -ne 0 ]]; then
    echo -e "This script must be run as root ... \e[1;31m[ERROR] \e[0m\n"
    exit 1
fi

os=$(source /etc/os-release && echo "$ID")
dateiss=$(date '+%Y-%m-%dT%H:%M:%S')

if [[ $os == "rhel" ]]; then
    container_manager="podman"
elif [[ $os == "ubuntu" ]] || [[ $os == "centos" ]]; then
    container_manager="docker"
fi

function logging_data() {
    if [[ $container_status == *"Exited"* ]]; then
        echo -e "Container $container_name is exited"
        echo "$(date '+%Y-%m-%dT%H:%M:%S') info: Container $container_name is exited" >> $LOG_FILE
        #echo -e "Starting the container $container_name........wait for 2 min"
        echo "$(date '+%Y-%m-%dT%H:%M:%S') info: Starting the container........ wait for 120s" >> $LOG_FILE
        start_container $container_manager $container_name
        container_status_new=$($container_manager ps -a --filter "name=$container_name" --format "{{.Status}}")
        if [[ $container_status_new == *"Up"* ]]; then
            echo -e "$container_name container is Up and Running"
            echo "$(date '+%Y-%m-%dT%H:%M:%S') info: Started container $container_name is Up and Running" | tee -a $LOG_FILE
        fi
    else
        echo -e "$container_name container is Up and Running"
        echo "$(date '+%Y-%m-%dT%H:%M:%S') info: Started container $container_name is Up and Running" | tee -a $LOG_FILE
    fi
}

function start_container() {
    local container_manager=$1
    local container_name=$2
    echo "$(date '+%Y-%m-%dT%H:%M:%S') : Starting the $container_name Container, wait for 120s..." | tee -a $LOG_FILE
    $container_manager start $container_name | tee -a $LOG_FILE
    sleep 120
    container_status=$($container_manager ps -a --filter "name=$container_name" --format "{{.Status}}")
    logging_data
    echo "$(date '+%Y-%m-%dT%H:%M:%S') info: $($container_manager ps -a)" | tee -a $LOG_FILE
}

function pc_start() {
    container_name="pico-v9"
    LOG_FILE="/DNIF/PICO/log/Activity.log"
    echo "$(date '+%Y-%m-%dT%H:%M:%S') : Checking the status of $container_name container..." | tee -a $LOG_FILE
    container_status=$($container_manager ps -a --filter "name=$container_name" --format "{{.Status}}")
    logging_data
}

function ad_start() {
    container_name="adapter-v9"
    LOG_FILE="/DNIF/AD/log/Activity.log"
    echo "$(date '+%Y-%m-%dT%H:%M:%S') : Checking the status of $container_name container..." | tee -a $LOG_FILE
    container_status=$($container_manager ps -a --filter "name=$container_name" --format "{{.Status}}")
    logging_data
}

function micro_ad_start() {
    ad_path=$(find /DNIF -type f -name "docker-compose.yaml" | grep -v '/DNIF/backup/ad' | grep -v '/DNIF/EB/docker-compose.yaml' | sed 's/\/docker-compose.yaml$//')
    for a in $ad_path; do
        cd "$a" || continue
        #container_name=$(grep -i "container_name:" ${os} == "rhel" ? "podman-compose.yaml" : "docker-compose.yaml" | awk '{print $2}')
        container_name=$(grep -i "container_name:" docker-compose.yaml | awk '{print $2}')
        LOG_FILE="$a/log/Activity.log"
        if [[ $os == "rhel" ]]; then
            start_container $container_manager "$container_name"
        else
            start_container $container_manager "$container_name"
        fi
    done
}

function micro_ad_start_new() {
    if [[ $(docker ps -a --format "{{.Names}}" | grep -i "eventbus-v9") == "eventbus-v9" ]]; then
        LOG_FILE="/DNIF/EB/log/Activity.log"
        echo "$(date '+%Y-%m-%dT%H:%M:%S') : Starting the eventbus-v9 Container, wait for 120s..." | tee -a $LOG_FILE
        start_container "docker" "eventbus-v9"
        sleep 120
        container_status=$(docker ps -a --filter "name=eventbus-v9" --format "{{.Status}}")
        if [[ $container_status == *"Up"* ]]; then
            micro_ad_start
        fi
    fi
}

function lc_start() {
    container_name="console-v9"
    LOG_FILE="/DNIF/LC/log/Activity.log"
    echo "$(date '+%Y-%m-%dT%H:%M:%S') : Checking the status of $container_name container..." | tee -a $LOG_FILE
    container_status=$($container_manager ps -a --filter "name=$container_name" --format "{{.Status}}")
    logging_data
}

function dn_start() {
    container_name="datanode-v9"
    LOG_FILE="/DNIF/DL/log/Activity.log"
    echo "$(date '+%Y-%m-%dT%H:%M:%S') : Checking the status of $container_name container..." | tee -a $LOG_FILE
    container_status=$($container_manager ps -a --filter "name=$container_name" --format "{{.Status}}")
    logging_data
    host_services_dn
}

function host_services_dn() {
    services=("spark-slave" "spark-master" "hadoop-datanode")
    for s in "${services[@]}"; do
        status=$(systemctl is-active $s.service)
        if [[ $status == "active" ]]; then
            echo -e "$s service is active and running"
            echo "$(date '+%Y-%m-%dT%H:%M:%S') info: $s service is active and running" | tee -a $LOG_FILE
        else
            echo -e "$s.service is not active"
            echo "$(date '+%Y-%m-%dT%H:%M:%S') info: $s.service is not active" | tee -a $LOG_FILE
            systemctl restart $s.service | tee -a $LOG_FILE
            echo -e "Restarting $s.service..........."
            echo "$(date '+%Y-%m-%dT%H:%M:%S') info: Restarting $s.service..........." | tee -a $LOG_FILE
            sleep 10
            status_new=$(systemctl is-active $s.service)
            if [[ $status_new == "active" ]]; then
                echo -e "Restarted $s.service and it is active and running"
                echo "$(date '+%Y-%m-%dT%H:%M:%S') info: Restarted $s.service and it is active and running" | tee -a $LOG_FILE
            fi
        fi
    done
}

function host_services_co() {
    services=("hadoop-namenode")
    for s in "${services[@]}"; do
        status=$(systemctl is-active $s.service)
        if [[ $status == "active" ]]; then
            echo -e "$s service is active and running"
            echo "$(date '+%Y-%m-%dT%H:%M:%S') info: $s service is active and running" | tee -a $LOG_FILE
        else
            echo -e "$s.service is not active"
            echo "$(date '+%Y-%m-%dT%H:%M:%S') info: $s.service is not active" | tee -a $LOG_FILE
            systemctl restart $s.service | tee -a $LOG_FILE
            echo -e "Restarting $s.service..........."
            echo "$(date '+%Y-%m-%dT%H:%M:%S') info: Restarting $s.service..........." | tee -a $LOG_FILE
            sleep 10
            status_new=$(systemctl is-active $s.service)
            if [[ $status_new == "active" ]]; then
                echo -e "Restarted $s.service and it is active and running"
                echo "$(date '+%Y-%m-%dT%H:%M:%S') info: Restarted $s.service and it is active and running" | tee -a $LOG_FILE
            fi
        fi
    done
}

function mdn_start() {
    if [[ $os == "rhel" ]]; then
        container_name="datanode-v9"
    else
        container_name="datanode-master-v9"
    fi
    LOG_FILE="/DNIF/CO/log/Activity.log"
    echo "$(date '+%Y-%m-%dT%H:%M:%S') : Checking the status of $container_name container..." | tee -a $LOG_FILE
    container_status=$($container_manager ps -a --filter "name=$container_name" --format "{{.Status}}")
    logging_data
}

function co_start() {
    container_name="core-v9"
    LOG_FILE="/DNIF/CO/log/Activity.log"
    echo "$(date '+%Y-%m-%dT%H:%M:%S') : Checking the status of $container_name container..." | tee -a $LOG_FILE
    container_status=$($container_manager ps -a --filter "name=$container_name" --format "{{.Status}}")
    logging_data
}

function core_start() {
    co_start
    mdn_start
    host_services_co
    if [[ $os == "ubuntu" ]] || [[ $os == "centos" ]]; then
        if [[ $(docker ps -a --format '{{.Names}}' | grep -w console-v9) == "console-v9" ]]; then
            lc_start
        fi
    elif [[ $(podman ps -a --format '{{.Names}}' | grep -w console-v9) == "console-v9" ]]; then
            lc_start
    fi
}

# Main Execution Logic
if [[ $os == "ubuntu" ]] || [[ $os == "centos" ]]; then
    if [[ $(docker ps -a --format '{{.Names}}' | grep -w core-v9) == "core-v9" ]]; then
        core_start
    elif [[ $(docker ps -a --format '{{.Names}}' | grep -w console-v9) == "console-v9" ]]; then
        lc_start
    elif [[ $(docker ps -a --format '{{.Names}}' | grep -w datanode-v9) == "datanode-v9" ]]; then
        dn_start
    elif [[ $(docker ps -a --format '{{.Names}}' | grep -w adapter-v9) == "adapter-v9" ]]; then
        ad_start
    elif [[ $(docker ps -a --format '{{.Names}}' | grep -w pico-v9) == "pico-v9" ]]; then
        pc_start
    elif [[ $(docker ps -a --format '{{.Names}}' | grep -w eventbus-v9) == "eventbus-v9" ]]; then
        micro_ad_start_new
    fi
elif [[ $os == "rhel" ]]; then
    if [[ $(podman ps -a --format '{{.Names}}' | grep -w core-v9) == "core-v9" ]]; then
        core_start
    elif [[ $(podman ps -a --format '{{.Names}}' | grep -w console-v9) == "console-v9" ]]; then
        lc_start
    elif [[ $(podman ps -a --format '{{.Names}}' | grep -w datanode-v9) == "datanode-v9" ]]; then
        dn_start
    elif [[ $(podman ps -a --format '{{.Names}}' | grep -w adapter-v9) == "adapter-v9" ]]; then
        ad_start
    elif [[ $(podman ps -a --format '{{.Names}}' | grep -w pico-v9) == "pico-v9" ]]; then
        pc_start
    fi
fi
