#!/bin/bash

# Ensure the script is run as root
if [[ $EUID -ne 0 ]]; then
    echo -e "This script must be run as root ... \e[1;31m[ERROR] \e[0m\n"
    exit 1
fi

os=$(source /etc/os-release && echo "$ID")
dateiss=$(date '+%Y-%m-%dT%H:%M:%S')

function logging_data() {
    if [[ $container_status == *"Exited"* ]]; then
        echo "$(date '+%Y-%m-%dT%H:%M:%S') info: Container $container_name is stopped." | tee -a $LOG_FILE
        echo "DNIF $container_name container is stopped"
    else
        echo "$(date '+%Y-%m-%dT%H:%M:%S') info: Container with name $container_name is not stopped." | tee -a $LOG_FILE
        echo "DNIF $container_name container is NOT stopped"
    fi
}

function stop_container() {
    local container_manager=$1
    local container_name=$2

    echo "$(date '+%Y-%m-%dT%H:%M:%S') : Stopping the $container_name Container, wait for 30s..." | tee -a $LOG_FILE
    $container_manager stop $container_name | tee -a $LOG_FILE
    sleep 30
    container_status=$($container_manager ps -a --filter "name=$container_name" --format "{{.Status}}")
    logging_data
    $container_manager ps -a
    echo "$(date '+%Y-%m-%dT%H:%M:%S') info: $($container_manager ps -a)" | tee -a $LOG_FILE
}

function pc_stop() {
    LOG_FILE="/DNIF/PICO/log/Activity.log"
    if [[ $os == "rhel" ]]; then
        stop_container "podman" "pico-v9"
    else
        stop_container "docker" "pico-v9"
    fi
}


function ad_stop() {
    LOG_FILE="/DNIF/AD/log/Activity.log"
    if [[ $os == "rhel" ]]; then
        stop_container "podman" "adapter-v9"
    else
        stop_container "docker" "adapter-v9"
    fi
}

function ad_stop_micro() {
    if [[ $(docker ps -a --format "{{.Names}}" | grep -i "eventbus-v9") == "eventbus-v9" ]]; then
        LOG_FILE="/DNIF/EB/log/Activity.log"
        stop_container "docker" "eventbus-v9"
        sleep 20
        container_status=$(docker ps -a --filter "name=eventbus-v9" --format "{{.Status}}")
        if [[ $container_status == *"Exited"* ]]; then
            micro_ad_stop
        else
            echo "$(date '+%Y-%m-%dT%H:%M:%S') info: Container with name EventBus is not stopped." | tee -a $LOG_FILE
            echo "$(date '+%Y-%m-%dT%H:%M:%S') : DNIF EventBus container is NOT stopped" | tee -a $LOG_FILE
            echo "$(date '+%Y-%m-%dT%H:%M:%S') : Exiting the script.... Contact DNIF Support" | tee -a $LOG_FILE
            exit 1
        fi
    fi
}

function micro_ad_stop() {
        ad_path=$(find /DNIF -type f -name "docker-compose.yaml" | grep -v '/DNIF/backup/ad' | grep -v '/DNIF/EB/docker-compose.yaml' | sed 's/\/docker-compose.yaml$//')
    for a in $ad_path; do
        cd "$a" || continue
        #container_name=$(grep -i "container_name:" ${os} == "rhel" ? "podman-compose.yaml" : "docker-compose.yaml" | awk '{print $2}')
        container_name=$(grep -i "container_name:" docker-compose.yaml | awk '{print $2}')
        LOG_FILE="$a/log/Activity.log"
        if [[ $os == "rhel" ]]; then
            stop_container "podman" "$container_name"
        else
            stop_container "docker" "$container_name"
        fi
    done
}

function dn_stop() {
    LOG_FILE="/DNIF/DL/log/Activity.log"
    if [[ $os == "rhel" ]]; then
        stop_container "podman" "datanode-v9"
    else
        stop_container "docker" "datanode-v9"
    fi
}

function co_stop() {
    LOG_FILE="/DNIF/CO/log/Activity.log"
    if [[ $os == "rhel" ]]; then
        if [[ $(podman ps -a --format '{{.Names}}' | grep -w console-v9) == "console-v9" ]]; then
            lc_stop
        fi
        stop_container "podman" "datanode-v9"
        stop_container "podman" "core-v9"
    else
        if [[ $(docker ps -a --format '{{.Names}}' | grep -w console-v9) == "console-v9" ]]; then
            lc_stop
        fi
        stop_container "docker" "datanode-master-v9"
        stop_container "docker" "core-v9"
    fi
}

function lc_stop() {
    LOG_FILE="/DNIF/LC/log/Activity.log"
    if [[ $os == "rhel" ]]; then
        stop_container "podman" "console-v9"
    else
        stop_container "docker" "console-v9"
    fi
}

# Main Execution Logic
if [[ $os == "ubuntu" ]] || [[ $os == "centos" ]]; then
    if [[ $(docker ps -a --format '{{.Names}}' | grep -w core-v9) == "core-v9" ]]; then
        co_stop
    elif [[ $(docker ps -a --format '{{.Names}}' | grep -w console-v9) == "console-v9" ]]; then
        lc_stop
    elif [[ $(docker ps -a --format '{{.Names}}' | grep -w datanode-v9) == "datanode-v9" ]]; then
        dn_stop
    elif [[ $(docker ps -a --format '{{.Names}}' | grep -w adapter-v9) == "adapter-v9" ]]; then
        ad_stop
    elif [[ $(docker ps -a --format '{{.Names}}' | grep -w pico-v9) == "pico-v9" ]]; then
        pc_stop
    elif [[ $(docker ps -a --format '{{.Names}}' | grep -w eventbus-v9) == "eventbus-v9" ]]; then
        ad_stop_micro
    fi
elif [[ $os == "rhel" ]]; then
    if [[ $(podman ps -a --format '{{.Names}}' | grep -w core-v9) == "core-v9" ]]; then
        co_stop
    elif [[ $(podman ps -a --format '{{.Names}}' | grep -w console-v9) == "console-v9" ]]; then
        lc_stop
    elif [[ $(podman ps -a --format '{{.Names}}' | grep -w datanode-v9) == "datanode-v9" ]]; then
        dn_stop
    elif [[ $(podman ps -a --format '{{.Names}}' | grep -w adapter-v9) == "adapter-v9" ]]; then
        ad_stop
    elif [[ $(podman ps -a --format '{{.Names}}' | grep -w pico-v9) == "pico-v9" ]]; then
        pc_stop
    fi
fi
